﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFDemoApp
{
    /// <summary>
    /// Interaction logic for ProductObjectDemo.xaml
    /// </summary>
    public partial class ProductObjectDemo : Window
    {
        public ProductObjectDemo()
        {
            InitializeComponent();
        }

        private void MainGrid_Loaded(object sender, RoutedEventArgs e)
        {
            Product product = new Product();
            lstProducts.DataContext = product.GetProducts();
        }

        private void lstProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MainGrid.DataContext = lstProducts.SelectedItem as Product;
        }
    }
}
