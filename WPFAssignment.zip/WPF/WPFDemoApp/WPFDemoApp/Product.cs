﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFDemoApp
{
    public class Product
    {
        public int ProductId { get; set; }

        public string ProductName { get; set; }

        public DateTime? MfgDate { get; set; }

        public decimal? Price { get; set; }

        
        public List<Product> GetProducts()
        {
            List<Product> productlist = new List<Product>()
            {
                new Product { ProductId = 101, ProductName = "Tea", Price = 100, MfgDate = Convert.ToDateTime("1/1/22") },

                new Product { ProductId = 102, ProductName = "Coffee", Price = 200, MfgDate = Convert.ToDateTime("2/2/22")}
            };
            return productlist;
        }
    }
}
