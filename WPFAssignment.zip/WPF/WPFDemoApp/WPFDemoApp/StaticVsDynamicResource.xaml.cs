﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFDemoApp
{
    /// <summary>
    /// Interaction logic for StaticVsDynamicResource.xaml
    /// </summary>
    public partial class StaticVsDynamicResource : Window
    {
        bool flag = false;
        public StaticVsDynamicResource()
        {
            InitializeComponent();
        }

        private void btnColor_Click(object sender, RoutedEventArgs e)
        {
            if (flag == false)
            {
                SolidColorBrush colorbrush = new SolidColorBrush(Colors.Blue);
                this.Resources["brush"] = colorbrush;
                flag = true;
            }
            else
            {
                SolidColorBrush colorbrush = new SolidColorBrush(Colors.Green);
                this.Resources["brush"] = colorbrush;
                flag = false;
            }
        }
    }
}
