﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace WPFDemoApp
{
    /// <summary>
    /// Interaction logic for ObservableCollectionDemo.xaml
    /// </summary>
    public partial class ObservableCollectionDemo : Window
    {
        ObservableCollection<Person> personList;
        public ObservableCollectionDemo()
        {
            InitializeComponent();

            personList = new ObservableCollection<Person>()
            {
                new Person() { FirstName= "Kaustubh", LastName= "Kulkarni", City= "Pune" },
                new Person() { FirstName= "Shri", LastName= "Kulkarni", City= "Akola"}
            };

            lstNames.DataContext = personList;

            LblCount.Content = "Total Person object = " + personList.Count;
        }

        private void btnAddPerson_Click(object sender, RoutedEventArgs e)
        {
            personList.Add(new Person() { FirstName = txtFName.Text, LastName = txtLName.Text, City = txtCity.Text });

            txtFName.Text = String.Empty;
            txtLName.Text = String.Empty;
            txtCity.Text = String.Empty;

            LblCount.Content = "Total Person Object = " + personList.Count;
        }
    }
}
